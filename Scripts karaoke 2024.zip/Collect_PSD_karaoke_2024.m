%Copyright (c) 2024 Tommi Makkonen
%License: MIT
%Permission is hereby granted, free of charge, to any person obtaining
%a copy of this software and associated documentation files (the
%"Software"), to deal in the Software without restriction, including
%without limitation the rights to use, copy, modify, merge, publish,
%distribute, sublicense, and/or sell copies of the Software, and to
%permit persons to whom the Software is furnished to do so, subject to
%the following conditions:
%The above copyright notice and this permission notice shall be included
%in all copies or substantial portions of the Software.
% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
%EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
%MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
%IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
%CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
%TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
%SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

% University of Helsinki
% Tommi Makkonen
clear all
clc

load(%'path to freqs.mat'); % file created by Powerspectraldensity script
datapath = %'path to .mat files';
pathContents = dir([datapath '\*.mat']);

% channels example
iChannels = {'F4','F3','C4','C3'};

fBand = [4 8]; % frequency band


winAve.N1 = [];
winAve.N2 = [];
winAve.N3 = [];
winAve.Rem = [];
subjects = [];
row = 0;

for f=1:size(pathContents,1)
    fname = pathContents(f,1).name;
    
    if contains(fname,'spectra')
        row = row+1;
        subjects{end+1} = fname(1:7);
        load([datapath '\' fname]);
        
        for ch=1:size(iChannels,2)
            N1data = spectra.N1{1,ch};
            PERUS = N1data;
            POLLO = detrend(N1data);
            if ~isempty(N1data)
                for sp=1:size(N1data,1)
                    freStart = find(freqs==fBand(1),1,'first');
                    freStop = find(freqs==fBand(2),1,'first');
                    winAve.N1{row,ch}(sp,1) = mean(N1data(sp,freStart:freStop));
                end
            end
            N2data = spectra.N2{1,ch};
            POLLO2 = detrend(N2data);
            if ~isempty(N2data)
                for sp=1:size(N2data,1)
                    freStart = find(freqs==fBand(1),1,'first');
                    freStop = find(freqs==fBand(2),1,'first');
                    winAve.N2{row,ch}(sp,1) = mean(N2data(sp,freStart:freStop));
                    
                end
            end
            N3data = spectra.N3{1,ch};
            if ~isempty(N3data)
                for sp=1:size(N3data,1)
                    freStart = find(freqs==fBand(1),1,'first');
                    freStop = find(freqs==fBand(2),1,'first');
                    winAve.N3{row,ch}(sp,1) = mean(N3data(sp,freStart:freStop));
                end
            end
            remdata = spectra.Rem{1,ch};
            if ~isempty(remdata)
                for sp=1:size(remdata,1)
                    freStart = find(freqs==fBand(1),1,'first');
                    freStop = find(freqs==fBand(2),1,'first');
                    winAve.Rem{row,ch}(sp,1) = mean(remdata(sp,freStart:freStop));
                end
            end
        end
        clear spectra;
    end
end

%%

N1data = [];

for r=1:size(winAve.N1,1)
    gmin = min(winAve.N1{r});
    

    for c=1:size(winAve.N1,2)
        if ~isempty(winAve.N1{r,c})
            if size(winAve.N1{r,c},1) > 1
                N1data(r,c) = mean(winAve.N1{r,c},1);
            else
                N1data(r,c) = winAve.N1{r,c};
                disp('Only one value');
            end
            N1data(r,c+6) = size(winAve.N1{r,c},1);
        else
            N1data(r,c) = NaN;
            N1data(r,c+6) = 0;
        end
    end
end

N2data = [];

for r=1:size(winAve.N2,1)
    for c=1:size(winAve.N2,2)
        if ~isempty(winAve.N2{r,c})
            if size(winAve.N2{r,c},1) > 1
                N2data(r,c) = mean(winAve.N2{r,c},1);
            else
                N2data(r,c) = winAve.N2{r,c};
            end
            N2data(r,c+6) = size(winAve.N2{r,c},1);
        else
            N2data(r,c) = NaN;
            N2data(r,c+6) = 0;
        end
    end
end

N3data = [];

for r=1:size(winAve.N3,1)
    for c=1:size(winAve.N3,2)
        if ~isempty(winAve.N3{r,c})
            if size(winAve.N3{r,c},1) > 1
                N3data(r,c) = mean(winAve.N3{r,c},1);
            else
                N3data(r,c) = winAve.N3{r,c};
            end
            N3data(r,c+6) = size(winAve.N3{r,c},1);
        else
            N3data(r,c) = NaN;
            N3data(r,c+6) = 0;
        end
    end
end

remdata = [];

for r=1:size(winAve.Rem,1)
    for c=1:size(winAve.Rem,2)
        if ~isempty(winAve.Rem{r,c})
            if size(winAve.Rem{r,c},1) > 1
                remdata(r,c) = mean(winAve.Rem{r,c},1);
            else
                remdata(r,c) = winAve.Rem{r,c};
            end
            remdata(r,c+6) = size(winAve.Rem{r,c},1);
        else
            remdata(r,c) = NaN;
            remdata(r,c+6) = 0;
        end
    end
end