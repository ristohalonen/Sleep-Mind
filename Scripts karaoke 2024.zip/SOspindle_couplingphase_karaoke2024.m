%Copyright (c) 2024 Risto Halonen
%License: MIT
%Permission is hereby granted, free of charge, to any person obtaining
%a copy of this software and associated documentation files (the
%"Software"), to deal in the Software without restriction, including
%without limitation the rights to use, copy, modify, merge, publish,
%distribute, sublicense, and/or sell copies of the Software, and to
%permit persons to whom the Software is furnished to do so, subject to
%the following conditions:
%The above copyright notice and this permission notice shall be included
%in all copies or substantial portions of the Software.
% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
%EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
%MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
%IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
%CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
%TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
%SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

%% Measure Phase Locking Value for overlapping spindles
% This cell is run for pre-processed .set files

% Timestamps of SO-coupled spindles must be in a separate file
% Format: SO_start\tSO_end\tSpindle_number\tSpindle_start\tSpindle_peak\tSpindle_end\tChannel

% This script uses EEGlab (tested in Matlab R2022b)
% Author Risto Halonen
% University of Helsinki


clear all
clc
plotFigures = true;

addpath %' EEGLAB path

subjects = %[subject ids];


fLow = 0.2; % lower edge of the frequency band
fHigh = 1.25; % higher edge of the frequency band

dirpath1 = %'directory path for SO-coupled spindle data'; 
dirpath2 = %'% .set data info path';
savedir = %'saving directory path';

% CHANNELS EXAMPLE
iChannels = {'F4','F3','C4','C3','M2','M1'}; % these will be analysed and impedance will be checked on these
epSize = 30; % epoch size in seconds (this must match the impedance, sleep stage, and artifact epochs)
nfft = 800; % In this case FFT window of 4 sec and 50% overlap, frequency resolution 0.25Hz (Sample rate 256Hz)

% Run eeglab and initialize
[ALLEEG EEG CURRENTSET ALLCOM] = eeglab;
telapsed = 0;
alltelapsed = zeros(1,size(subjects,2));
msg = 'Processing data. Please wait...';
waitb = waitbar(0,msg);

M1ch = find(strcmp(iChannels,'M1'));
M2ch = find(strcmp(iChannels,'M2'));

% Run subjects in a loop
for s=1:size(subjects,2)

    STUDY = []; CURRENTSTUDY = 0; ALLEEG = []; EEG=[]; CURRENTSET=[];

    %EXAMPLE FILE NAME
    datafilename = ['kh' num2str(subjects(s)) '_02-35Hz_8chs.set'];

    EEG = pop_loadset('filename',datafilename,'filepath',dirpath2);
    
    writefilename = [savedir num2str(subjects(s)) '.txt']; %savedir and output filename for each subject
    writefile = fopen(writefilename, 'w');

    if exist([dirpath1 num2str(subjects(s)) '.txt'],'file') == 2
        spindle_file = [dirpath1 num2str(subjects(s)) '.txt'];
        fid = fopen(spindle_file);
    else
        disp('Spindles not found')
    end

    % Search for channel indices in EEG data
    labels = cell(EEG.nbchan,1);
    for ch = 1:EEG.nbchan
        chlabel = EEG.chanlocs(ch,1).labels;
        labels{ch,1} = chlabel;
    end

    chinds = zeros(1,size(iChannels,2));
    for dch=1:size(iChannels,2)
        chIndex = find(strcmp(labels,iChannels{dch}));
        if ~isempty(chIndex)
            chinds(dch) = find(strcmp(labels,iChannels{dch}));

        end
    end

    F4_ch = find(strcmp(labels, 'F4'));
    F3_ch = find(strcmp(labels, 'F3'));
    C4_ch = find(strcmp(labels, 'C4'));
    C3_ch = find(strcmp(labels, 'C3'));   
    M1ind = find(strcmp(labels,'M1'));
    M2ind = find(strcmp(labels,'M2'));

    % Rereference to mastoids
    msg = ['Re-referencing EEG data...  '];

    EEG = pop_reref( EEG, [M1ind M2ind] ,'keepref','on');
    [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, 1,'gui','off'); 
    EEG = eeg_checkset( EEG );

    % Filter the data using defined cut-off values
    msg = ['Filtering EEG data...  '];

    EEG = pop_firws(EEG, 'fcutoff', [fLow fHigh], 'ftype', 'bandpass', 'wtype', 'blackman', 'forder', 3520, 'minphase', 0);
    [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, 4,'gui','off');

    F4_PP = [];
    F3_PP = [];
    C4_PP = [];
    C3_PP = [];

    %Reading SO-spindle file
    %file format (named as the subject ID):
    %SO_start\tSO_end\tSpindle_number\tSpindle_start\tSpindle_peak\tSpindle_end\tChannel

    sline = fgetl(fid);
    
    while ischar(sline)
        sline = strrep(sline, "'", "");
        a = split(sline, char(9));
        sp_ch = strrep(a(7), " (channels)", "");
        EEG_ch = find(strcmp(labels,sp_ch));
        
        sp_peak = round((str2double(a(5)))*EEG.srate);

        SO_start = round((str2double(a(1)))*EEG.srate);
        SO_end = round((str2double(a(2)))*EEG.srate);

        signal = EEG.data(EEG_ch, (SO_start):(SO_end));
        peak_time = sp_peak - SO_start;

        SO_phase = angle(hilbert(signal));


        if string(sp_ch) == 'F4'
            F4_PP(end + 1) = SO_phase(peak_time+1);

        elseif string(sp_ch) == 'F3'
            F3_PP(end + 1) = SO_phase(peak_time+1);

        elseif string(sp_ch) == 'C4'
            C4_PP(end + 1) = SO_phase(peak_time+1);

        elseif string(sp_ch) == 'C3'
            C3_PP(end + 1) = SO_phase(peak_time+1);

        end
        sline = fgetl(fid);

    end

    if writefile ~= -1
      fprintf(writefile, '%g\t', F4_PP);
      fprintf(writefile, '\n');

      fprintf(writefile, '%g\t', F3_PP);
      fprintf(writefile, '\n');

      fprintf(writefile, '%g\t', C4_PP);
      fprintf(writefile, '\n');

      fprintf(writefile, '%g\t', C3_PP);
      fprintf(writefile, '\n');


      fclose(writefile);
    end
end
delete(waitb)
