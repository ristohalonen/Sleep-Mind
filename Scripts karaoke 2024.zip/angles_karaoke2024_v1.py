import numpy as np
import os, fnmatch
import math
import matplotlib.pyplot as plt
import pycircstat
import numpy


angledir = #'directory of angle files' # format: '\channel1_angle1\tchannel1_angle2\tchannel1_angle3...\nchannel2_angle1...'

listoffiles = os.listdir(angledir)
anglestats = open(#'output file', 'w')

for file in listoffiles:

    anglestats.write(file + '\t')
    
    angles = open(angledir + file, 'r')
    
    #Read angle data

    for line in angles:

        anglelist = line.split('\t')
        anglelist.pop()
    
        A = [float(x) for x in anglelist]
        A = numpy.array(A)

        # Calculate RVL

        ch_rvl = pycircstat.resultant_vector_length(A)
        i = 0

        # Calculate spindles within 0.5 radians from SO mean angle
        
        ch_OC = 0
        while i < len(A):
            if pycircstat.cdiff(pycircstat.mean(A), A[i]) <= 0.5:
                ch_OC = ch_OC + 1
            i = i + 1

        anglestats.write(str(ch_mean) + '\t' + str(ch_rvl) + '\t' + str(ch_OC) + '\t')
    anglestats.write('\n')

    angles.close()
anglestats.close()
    


