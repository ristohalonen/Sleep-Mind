%Copyright (c) 2024 Tommi Makkonen
%License: MIT
%Permission is hereby granted, free of charge, to any person obtaining
%a copy of this software and associated documentation files (the
%"Software"), to deal in the Software without restriction, including
%without limitation the rights to use, copy, modify, merge, publish,
%distribute, sublicense, and/or sell copies of the Software, and to
%permit persons to whom the Software is furnished to do so, subject to
%the following conditions:
%The above copyright notice and this permission notice shall be included
%in all copies or substantial portions of the Software.
% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
%EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
%MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
%IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
%CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
%TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
%SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.


% Clear Workspace
clear all;

% Clear Command Window
clc;
% Set character encoder to utf-8
slCharacterEncoding('UTF-8');

% Session ID:s
sessions = {'a','b','c','d'};

% --- USE EEGLAB TO LOAD THE DATA --- %
% Add eeglab to the path. 
addpath(%eeglab folder);

% Start eeglab ( We only need the pop_loadbv() function from eeglab. However,
% importing only pieces of eeglab can be annoying)
[ALLEEG EEG CURRENTSET ALLCOM] = eeglab;
close gcf;

% Set the name of the output file: fileToSave
fileToSave = 'results.csv';

% Set the name of the data folder: datafolder 

datafolder = '% EDA data path';

% Find the datafiles
list=dir(datafolder);
files={list(~[list.isdir]).name};
files=files(endsWith(files,'.vhdr'));

% Define output column names as cell array: H
H{1,1} = 'filename';
H{1,2} = 'baseline-singing_mean';
H{1,3} = 'karaoke-singing_mean';
H{1,4} = 'afterline-singing_mean';
H{1,5} = 'baseline-playback1_mean';
H{1,6} = 'karaoke-playback1_mean';
H{1,7} = 'afterline-playback1_mean';
H{1,8} = 'baseline-playback2_mean';
H{1,9} = 'karaoke-playback2_mean';
H{1,10} = 'afterline-playback2_mean';
H{1,11} = 'baseline-playback3_mean';
H{1,12} = 'karaoke-playback3_mean';
H{1,13} = 'afterline-playback3_mean';
H{1,14} = 'baseline-singing_max';
H{1,15} = 'karaoke-singing_max';
H{1,16} = 'afterline-singing_max';
H{1,17} = 'baseline-playback1_max';
H{1,18} = 'karaoke-playback1_max';
H{1,19} = 'afterline-playback1_max';
H{1,20} = 'baseline-playback2_max';
H{1,21} = 'karaoke-playback2_max';
H{1,22} = 'afterline-playback2_max';
H{1,23} = 'baseline-playback3_max';
H{1,24} = 'karaoke-playback3_max';
H{1,25} = 'afterline-playback3_max';

subjects = cell(1,size(files,2));
for i=1:size(files,2)
    subjects{i} = files{i}(1:end-6);
end
subjects = unique(subjects);

for i=1:size(subjects,2)   
    T{i,1} = subjects{i};
    
    for j=1:size(sessions,2)
        % Save and print current filename: datafilename
        datafilename = [subjects{i} sessions{j} '.vhdr'];
        disp(['Reading file ' datafilename])
    
        % Load the data: EEG
        disp(datafolder)
        disp(datafilename)
        
        EEG = pop_loadbv(datafolder, datafilename, [], []); % Load the data
    
        % Extract useful stuff from EEG %
        s=EEG.data(1,:); % Skin conductance signal
        ind=[1:length(s)]; % sample indexes
        rate=EEG.srate; %sampling rate
        t=ind/rate; % time axis
        latency=[EEG.event.latency]; % indexes of events
        type={EEG.event.type}; % trigger codes of events
    
        % Reset result to NaN's
        b_ave = NaN; a_ave= NaN; ks_ave= NaN;
        kp1_ave= NaN; kp2_ave= NaN; kp3_ave= NaN;
    
        % Find baseline indexes and calc the average

        b = latency(strcmp(type, 'b'))+ 60000;
        bs = latency(strcmp(type,'bs'))-10000;

        b_ave = mean(s(b:bs));
        b_max = max(s(b:bs));
        
        if strcmp(sessions{j},'a')
            T{i,2} = b_ave;
            T{i,14} = b_max;
        elseif strcmp(sessions{j},'b')
            T{i,5} = b_ave;
            T{i,17} = b_max;
        elseif strcmp(sessions{j},'c')
            T{i,8} = b_ave;
            T{i,20} = b_max;
        elseif strcmp(sessions{j},'d')
            T{i,11} = b_ave;
            T{i,23} = b_max;
        end
    
        % Find afterline indexes and calc the average
        a=latency(strcmp(type,'a'));
        as=latency(strcmp(type,'as'));
        a_ave= mean(s(a:as));
        a_max= max(s(a:as));
        
        if strcmp(sessions{j},'a')
            T{i,4} = a_ave;
            T{i,16} = a_max;
        elseif strcmp(sessions{j},'b')
            T{i,7} = a_ave;
            T{i,19} = a_max;
        elseif strcmp(sessions{j},'c')
            T{i,10} = a_ave;
            T{i,22} = a_max;
        elseif strcmp(sessions{j},'d')
            T{i,13} = a_ave;
            T{i,25} = a_max;
        end
    
        % Find karaoke-singing indexes and calc the average
        ks=latency(strcmp(type,'ks'));
        kss=latency(strcmp(type,'kss'));
        ks_ave= mean(s(ks:kss));
        ks_max= max(s(ks:kss));
        
        if strcmp(sessions{j},'a')
            T{i,3} = ks_ave;
            T{i,15} = ks_max;

        end
    
        % Find karaoke-playback1 indexes and calc the average
        kp1=latency(strcmp(type,'kp1'));
        kp1s=latency(strcmp(type,'kp1s'));
        kp1_ave= mean(s(kp1:kp1s));      
        kp1_max= max(s(kp1:kp1s));
        
        if strcmp(sessions{j},'b')
            T{i,6} = kp1_ave;
            T{i,18} = kp1_max;
                 
        end
        
        
        % Find karaoke-playback2 indexes and calc the average
        kp2=latency(strcmp(type,'kp2'));
        kp2s=latency(strcmp(type,'kp2s'));
        kp2_ave= mean(s(kp2:kp2s));
        kp2_max= max(s(kp2:kp2s));
        
        if strcmp(sessions{j},'c')
            T{i,9} = kp2_ave;
            T{i,21} = kp2_max;
    
            middle2 = ((T{i,21})+(T{i,8}))/2
   
        end
        
        
        % Find karaoke-playback3 indexes and calc the average
        kp3=latency(strcmp(type,'kp3'));
        kp3s=latency(strcmp(type,'kp3s'));
        kp3_ave= mean(s(kp3:kp3s));
        kp3_max= max(s(kp3:kp3s));
        
        if strcmp(sessions{j},'d')
            T{i,12} = kp3_ave;
            T{i,24} = kp3_max;
                      
        end
    end   
end


% Combine header H to table T
H=[H;T];

% Convert cell to Table format
Tbl =cell2table(H);

% Write results
writetable(Tbl,fileToSave, 'Delimiter', ',','Encoding','UTF-8','WriteVariableNames',false);

