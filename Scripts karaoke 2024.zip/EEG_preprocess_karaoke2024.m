%Copyright (c) 2024 Tommi Makkonen
%License: MIT
%Permission is hereby granted, free of charge, to any person obtaining
%a copy of this software and associated documentation files (the
%"Software"), to deal in the Software without restriction, including
%without limitation the rights to use, copy, modify, merge, publish,
%distribute, sublicense, and/or sell copies of the Software, and to
%permit persons to whom the Software is furnished to do so, subject to
%the following conditions:
%The above copyright notice and this permission notice shall be included
%in all copies or substantial portions of the Software.
% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
%EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
%MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
%IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
%CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
%TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
%SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.



%% Preprocess data
% Channel selection and Band-pass filtering
% this cell is run first for all subjects

% This script uses EEGlab (tested in Matlab R2022b)
% Author Tommi Makkonen
% University of Helsinki

clear all
clc

subjects = [%subcjects] % list of subject IDs

dirpath = '%EDF data path'; % edf-data
savepath = '%path for .set files';

addpath %EEGLAB path

msg = 'Processing data. Please wait...';
waitb = waitbar(0,msg);
telapsed = 0;

for s=1:size(subjects,2)
    t1 = tic;
    
    if s > 1
        timeleft = telapsed*(size(subjects,2)-s+1);
        
        mins = floor(timeleft/60);
        secs = floor(timeleft-mins*60);
        
        if mins > 0
            msg = sprintf('Processing. Estimated time left: %i min %i sec. Please wait...',mins,secs);
        else
            msg = sprintf('Processing. Estimated time left: %i sec. Please wait...',secs);
        end
        %waitbar((s-1)/size(subjects,2),waitb,msg);
    end
    
    % Load PSG data
    edffile = [dirpath '\' num2str(subjects(s)) '.edf'];
    disp(edffile)
    [ALLEEG EEG CURRENTSET ALLCOM] = eeglab;
    EEG = pop_biosig(edffile,'importevent','off');
    [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, 0,'gui','off');
    EEG = eeg_checkset( EEG );
    
    % Select channels EXAMPLE
    EEG = pop_select( EEG,'channel',{'F3' 'F4' 'C3' 'C4' 'M1' 'M2'});
    [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, 1,'gui','off');
    
    % Filter
    
    EEG = pop_eegfiltnew(EEG, 'locutoff',0.2,'hicutoff',35);
    [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, 2,'gui','off');
    
    % Save in .set format
    EEG = eeg_checkset( EEG );
    
    newfilename = [% filename of the .set file];
    EEG = pop_saveset( EEG, 'filename',newfilename,'filepath',savepath);

    telapsed = toc(t1);
end
delete(waitb)
