#Copyright (c) 2024 Risto Halonen
#License: MIT
#Permission is hereby granted, free of charge, to any person obtaining
#a copy of this software and associated documentation files (the
#"Software"), to deal in the Software without restriction, including
#without limitation the rights to use, copy, modify, merge, publish,
#distribute, sublicense, and/or sell copies of the Software, and to
#permit persons to whom the Software is furnished to do so, subject to
#the following conditions:
#The above copyright notice and this permission notice shall be included
#in all copies or substantial portions of the Software.
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
#EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
#MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
#IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
#CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
#TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
#SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

import os, fnmatch
import pycircstat
import numpy


#angledir = #'directory of angle files' # format: '\channel1_angle1\tchannel1_angle2\tchannel1_angle3...\nchannel2_angle1...'
angledir = 'D:/Backup/Work/Karaoke2021/temppi/'

listoffiles = os.listdir(angledir)
anglestats = open('./moimoi.txt', 'w')#'output file', 'w')

for file in listoffiles:
    print(file)

    anglestats.write(file + '\t')
    
    angles = open(angledir + file, 'r')
    
    #Read angle data

    for line in angles:

        anglelist = line.split('\t')
        anglelist.pop()
    
        A = [float(x) for x in anglelist]
        A = numpy.array(A)

        # Calculate RVL

        ch_rvl = pycircstat.resultant_vector_length(A)
        i = 0

        # Calculate spindles within 0.5 radians from SO mean angle
        
        ch_OC = 0
        while i < len(A):
            if pycircstat.cdiff(pycircstat.mean(A), A[i]) <= 0.5:
                ch_OC = ch_OC + 1
            i = i + 1

        anglestats.write(str(ch_rvl) + '\t' + str(ch_OC) + '\t')
    anglestats.write('\n')

    angles.close()
anglestats.close()
    


