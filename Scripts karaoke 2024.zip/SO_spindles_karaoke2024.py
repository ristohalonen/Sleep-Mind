#Copyright (c) 2024 Risto Halonen
#License: MIT
#Permission is hereby granted, free of charge, to any person obtaining
#a copy of this software and associated documentation files (the
#"Software"), to deal in the Software without restriction, including
#without limitation the rights to use, copy, modify, merge, publish,
#distribute, sublicense, and/or sell copies of the Software, and to
#permit persons to whom the Software is furnished to do so, subject to
#the following conditions:
#The above copyright notice and this permission notice shall be included
#in all copies or substantial portions of the Software.
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
#EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
#MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
#IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
#CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
#TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
#SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

# Script for finding slow oscillations during which sleep spindle power peaks exist.
# Input1: Wonambi 7.x format slow oscillation export file(s)
# Input2: Wonambi 7.x format sleep spindle export file(s) containing spindle peak timestamp


import os, fnmatch
from statistics import mean

#directory1 = #'directory of spindle files'
#directory2 = #'directory of slow oscillation files'
#directory3 = #SO-spindle output directory

listOfFiles = os.listdir(directory1)

for file in listOfFiles:
    kh = file.replace('.txt', '')

    #Open spindle data
    spindles = open(directory1 + file, 'r')
    
    output_filepath = directory3 + kh + '.txt'

    output_file = open(output_filepath, 'w')

    #Read headers
    spindles.readline()

    #Read individual spindle data
    for line_sp in spindles:
        
        #Note: edit to match export file format        
        ind_sp, spindle_start, spindle_peak, spindle_end, ch_sp = line_sp.split('\t')

        #open slow oscillation file
        sos = open(directory2 + #subject's slow oscillation file, 'r')

        #Read headers
        sos.readline()
        sos.readline()    

        #Find the slow oscillation where the spindle peaks
        for line_sos in sos:

            #Note: edit to match export file format 
            ind_so, so_start, so_peak, so_end, stiches_so, stage_so, cycle_so, event_so, ch_so = line_sos.split(',')

            # Find spindle peaks during SOs in the same channel
                           
            if ch_so == ch_sp and float(so_start) <= (float(spindle_peak)) < float(so_end):

                #Write SO-spindle line for each found SO-coupled spindle
                output_file.write(so_start + '\t' + so_end + '\t' + line_sp)      
                    
        sos.close()

    spindles.close()
    output_file.close()
