%Copyright (c) 2024 Tommi Makkonen
%License: MIT
%Permission is hereby granted, free of charge, to any person obtaining
%a copy of this software and associated documentation files (the
%"Software"), to deal in the Software without restriction, including
%without limitation the rights to use, copy, modify, merge, publish,
%distribute, sublicense, and/or sell copies of the Software, and to
%permit persons to whom the Software is furnished to do so, subject to
%the following conditions:
%The above copyright notice and this permission notice shall be included
%in all copies or substantial portions of the Software.
% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
%EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
%MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
%IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
%CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
%TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
%SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

% Calculate spectral power
% This cell is run for pre-processed .set files
% Check paths to:
% 1) sleep stage .txt-files
% 2) pre-processed .set-files
% 3) impedance info .txt-files
% 4) saving directory

% Sleep stage and impedance info has to be in specific format (SomnoMedics Domino)

% This script uses EEGlab (tested in Matlab R2022b)
% Author Tommi Makkonen
% University of Helsinki

clear all
clc
plotFigures = true;
subjects = [9321] % list of subject IDs]; 

dirpath1 = %'sleep stage info folder path';
dirpath2 = %'.set data info folder path';
dirpath3 = %'impedance info folder path';
dirpath4 = %'txt file containing sleep start and stop times';
savedir = %'save data path'; % saving directory';;


iChannels = {'F4','F3','C4','C3','M2','M1'}; % these will be analysed and impedance will be checked on these
epSize = 30; % epoch size in seconds (this must match the impedance, sleep stage, and artifact epochs)
nfft = 1024; % In this case FFT window of 4 sec and 50% overlap, frequency resolution 0.25Hz (Sample rate 256Hz)

% Run eeglab and initialize
addpath addpath C:\LocalData\ristohal\eeglab2023.0\ (%'eeglab path');
[ALLEEG EEG CURRENTSET ALLCOM] = eeglab;
telapsed = 0;
alltelapsed = zeros(1,size(subjects,2));
msg = 'Processing data. Please wait...';
waitb = waitbar(0,msg);

epochNumbers = zeros(size(subjects,2),size(iChannels,2));

fidSW = fopen(dirpath4);
SWdata = textscan(fidSW,'%s%d%d','headerlines',1);
fclose(fidSW);

A1ch = find(strcmp(iChannels,'M1'));
A2ch = find(strcmp(iChannels,'M2'));

% Run subjects in a loop
for s=1:size(subjects,2)
    
    % Handle process time estimation
    t_start = tic; 
    if s > 1
        alltelapsed(s) = telapsed;
        meanOfOne = mean(nonzeros(alltelapsed),1); % sec
        subjsLeft = size(subjects,2)-s+1;
        
        mins = floor(meanOfOne/60*subjsLeft);

        msg = ['Processing. Estimated time left: ' num2str(mins) ' min.'];
        waitbar(((s-1)/size(subjects,2)),waitb,msg); 
    end
    
    spectra.N1 = cell(1,size(iChannels,2));
    spectra.N2 = cell(1,size(iChannels,2));
    spectra.N3 = cell(1,size(iChannels,2));
    spectra.Rem = cell(1,size(iChannels,2));
        
        fileInd = find(strcmp(SWdata{1,1},[num2str(subjects(s))]));
        sleepTime = SWdata{1,2}(fileInd);
        wakeTime = SWdata{1,3}(fileInd);
        
        %hypnogram and impedance files
        hypnofile = [dirpath1 '\Sleep profile - ' num2str(subjects(s)) '.txt'];
        impedanceFile = [dirpath3 '\Impedance - ' num2str(subjects(s)) '.txt'];
    
        if exist(hypnofile,'file') == 2 && exist(impedanceFile,'file') == 2
            
        
            if s > 1
                msg = ['Reading metadata... Estimated time left: ' num2str(mins) ' min.'];
            else
                msg = 'Reading metadata...';
            end
            waitbar(((s-1)/size(subjects,2)),waitb,msg);
            
            % load impedance file
            fidI = fopen(impedanceFile);
            impedanceData = textscan(fidI,'%s%d,%s','headerlines',7);
            fclose(fidI);
            
            % load hypnogram
            fidH = fopen(hypnofile);
            hypnodata = textscan(fidH,'%s%s','delimiter', ' ','headerlines',7);
            fclose(fidH);
            
            times = hypnodata{1,1};
            % Find first sleep block
            dt = datestr(times(1),'HH:MM:SS');
            dt = datetime( dt ) + seconds(sleepTime); 
            dt = datestr(dt,'HH:MM:SS');
            sleepInd = find(strcmp(hypnodata{1,1},[dt ',000;']));
            
            % Find last sleep block
            dt = datestr(times(1),'HH:MM:SS');
            dt = datetime( dt ) + seconds(wakeTime); 
            dt = datestr(dt,'HH:MM:SS');
            wakeInd = find(strcmp(hypnodata{1,1},[dt ',000;']));
            
            datamatrix = cell(wakeInd-sleepInd,2+size(iChannels,2)); % matrix for all the metadata
            for ti=1:size(datamatrix,1)
                datamatrix{ti,1} = datestr(times(sleepInd+ti-1),'HH:MM:SS');
                datamatrix{ti,2} = hypnodata{1,2}(sleepInd+ti-1,1);
            end
        
            if s > 1
                msg = ['Checking impedances... Estimated time left: ' num2str(mins) ' min.'];
            else
                msg = 'Checking impedances...';   
            end
        
            % Create metadata "datamatrix": check impedance and add 1 to column numchs if less than 10kOhm
            last_i = 1;
            for bi=1:size(datamatrix,1)
            
                msg = ['Checking impedances...  ' num2str(round((bi/(size(datamatrix,1)-1))*100)) ' % done.'];
                waitbar(((s-1)/size(subjects,2)),waitb,msg);
            
                t1 = datamatrix{bi,1};
                if bi < size(datamatrix,1)
                    t2 = datamatrix{bi+1,1};
                else
                    t2 = datestr(datetime(t1)+seconds(30),'HH:MM:SS');
                end
            
                for i=last_i:size(impedanceData{1,1},1)
                    it = impedanceData{1,1}{i};
                    hhmmss = it(1:8);
                    if strcmp(t1,hhmmss)
                        impstart = i;
                        break
                    end
                end
                for j=i:size(impedanceData{1,1},1)
                    it = impedanceData{1,1}{j};
                    hhmmss = it(1:8);
                    if strcmp(t2,hhmmss)
                        impstop = j-1;
                        break
                    end
                end
            
                last_i = j;
            
                blockChs = impedanceData{1,3}(impstart:impstop);

                impedances = impedanceData{1,2}(impstart:impstop,1);
                chImp = [];
                chok = cell(1,size(iChannels,2));
            
                for bch=1:size(blockChs,1)
                    for ich=1:size(iChannels,2)
                    
                        if strcmpi(blockChs{bch,1},iChannels{ich})
                            chImp{end+1,1} = bch;
                            chImp{end,2} = blockChs{bch,1};
                            chImp{end,3} = impedances(bch,1);
                            if impedances(bch,1) <= 30
                                chImp{end,4} = 1;
                                chok{ich}(end+1) = 1;
                            else
                                chImp{end,4} = 0;
                                chok{ich}(end+1) = 0;
                            end
                        end
                    end
                end
                for ich=1:size(iChannels,2)
                    if sum(chok{ich}(:)) == size(chok{ich},2)
                        datamatrix{bi,2+ich} = 1;
                    else
                        datamatrix{bi,2+ich} = 0;
                    end
                end
            end
    
            for ich=1:size(iChannels,2)
                epochNumbers(s,ich) = sum(cell2mat(datamatrix(:,2+ich)));
            end
        
            % Load preprocessed EEG data (.set)

            datafilename = ['kh' num2str(subjects(s)) '_02-35Hz_8chs.set'];

            EEG = pop_loadset('filename',datafilename,'filepath',dirpath2);

            % Search for channel indices in EEG data
            labels = cell(EEG.nbchan,1);
            for ch = 1:EEG.nbchan
                chlabel = EEG.chanlocs(ch,1).labels;
                labels{ch,1} = chlabel;
            end
    
            chinds = zeros(1,size(iChannels,2));
            for dch=1:size(iChannels,2)
                chIndex = find(strcmp(labels,iChannels{dch}));
                if ~isempty(chIndex)
                    chinds(dch) = find(strcmp(labels,iChannels{dch}));
                end
            end

            A1ind = find(strcmp(labels,'M1'));
            A2ind = find(strcmp(labels,'M2'));
            
            % Rereference to mastoids
            EEG = pop_reref( EEG, [A1ind A2ind] ,'keepref','on');
            [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, 1,'gui','off'); 
            EEG = eeg_checkset( EEG );
              

            % Process EEG epochs 
            EEGstart = floor(sleepTime*EEG.srate);
            EEGstop = floor(wakeTime*EEG.srate);
            L = floor(epSize*EEG.srate);
            
            for ve=1:size(datamatrix,1)

                msg = ['Processing EEG data...  ' num2str(round((ve/(size(datamatrix,1)-1))*100)) ' % done.'];
                waitbar(((s-1)/size(subjects,2)),waitb,msg);

                start_s = EEGstart + floor(epSize*EEG.srate)*(ve-1);
                stop_s = start_s+L-1; 

                for ich=1:size(chinds,2)
                    valid = 0;
                    if ~isempty(datamatrix{ve,2+ich})
                        if datamatrix{ve,2+ich} == 1
                            epoch = EEG.data(chinds(ich),start_s:stop_s);
                            valid = 1;
                        end
                    end

                    if valid == 1
                        epoch = epoch - mean(epoch,2); % remove DC
                        if sum(epoch) ~= 0 % no flat channels
                            [spectr freqs] = spectopo(epoch, L, EEG.srate, 'winsize', nfft, 'nfft', nfft, 'overlap', nfft/2, 'plot', 'off');

                            if strcmp(datamatrix{ve,2},'N1')
                                spectra.N1{1,ich}(end+1,:) = spectr;        
                            elseif strcmpi(datamatrix{ve,2},'N2')
                                spectra.N2{1,ich}(end+1,:) = spectr;  
                            elseif strcmpi(datamatrix{ve,2},'N3')
                                spectra.N3{1,ich}(end+1,:) = spectr;  
                            elseif strcmpi(datamatrix{ve,2},'REM')
                                spectra.Rem{1,ich}(end+1,:) = spectr;  
                            end
                        end
                    end
                end
            end
    
            filepath = [savedir '\kh' num2str(subjects(s)) '_datamatrix.mat'];

            save(filepath,'datamatrix')
            filepath = [savedir '\kh' num2str(subjects(s)) '_spectra.mat'];

            save(filepath,'spectra')
    
            if plotFigures == true
                figure
                suptitle(['Subject ' num2str(subjects(s))])

                for ich=1:size(chinds,2)
                    subplot(3,3,ich)
                    if ~isempty(spectra.N1{1,ich})
                        if size(spectra.N1{1,ich},1) > 1
                            plot(freqs,mean(spectra.N1{1,ich},1),'r')
                            xlim([0 50])
                            hold on
                        end
                    end
                    if ~isempty(spectra.N2{1,ich})
                        if size(spectra.N2{1,ich},1) > 1
                            plot(freqs,mean(spectra.N2{1,ich},1),'k')
                            xlim([0 50])
                            hold on
                        end
                    end
                    if ~isempty(spectra.N3{1,ich})
                        if size(spectra.N3{1,ich},1) > 1
                            plot(freqs,mean(spectra.N3{1,ich},1),'b')
                            xlim([0 50])
                            hold on
                        end
                    end
                    if ~isempty(spectra.Rem{1,ich})
                        if size(spectra.Rem{1,ich},1) > 1
                            plot(freqs,mean(spectra.Rem{1,ich},1),'g')
                            xlim([0 50])
                            hold on
                        end
                    end
                
                    title(iChannels{ich})
                end
                legend('N1','N2','N3','Rem')
                filepath = [savedir '\kh' num2str(subjects(s)) '_spectra.fig'];

                savefig(filepath)
            end
        else
            msg = sprintf('Not found!')
            
        end
        STUDY = []; CURRENTSTUDY = 0; ALLEEG = []; EEG=[]; CURRENTSET=[];
    end
    telapsed = toc(t_start);
%end
delete(waitb)
